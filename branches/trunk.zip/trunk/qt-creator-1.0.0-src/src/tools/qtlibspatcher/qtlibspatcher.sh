#!/bin/bash
LD_LIBRARY_PATH=`cd .. && pwd`/lib ./qtlibspatcher "$@"
