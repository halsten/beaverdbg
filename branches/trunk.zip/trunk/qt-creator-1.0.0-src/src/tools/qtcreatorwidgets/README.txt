A Designer custom widget collection containing the Qt Creator
widgets from the utils library.

Installs to Designer and has rpath pointing to the QtCreator library
directory, so, it should work on Linux.

On Windows, it might require copying the utils library around or setup
some path pointing to it.
