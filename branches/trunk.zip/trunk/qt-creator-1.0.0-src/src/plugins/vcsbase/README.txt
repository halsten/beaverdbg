TODO:

When diffing:
- Use code from current editor or
- else from project or
- System codec
